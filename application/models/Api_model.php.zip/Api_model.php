<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api_model extends CI_Model
{

public function get_tournamentdata($limit)
{
    $userId = $this->input->post('user_id');
    $sports_category = json_decode($this->input->post('sports_category'));
    $state = json_decode($this->input->post('state'));
    $city = json_decode($this->input->post('city'));
    $status = json_decode($this->input->post('status'));

    $this->db->select('tbl_sportcategory.title as sportname , tbl_tournament.tournament_title, tbl_tournament.fee as amount, tbl_tournament.description, tbl_tournament.status, tbl_tournament.cover_image as image,tbl_tournament.id as tournament_id,tbl_tournament.city,tbl_tournament.state');
    $this->db->join('tbl_sportcategory','tbl_sportcategory.id=tbl_tournament.sports_category','left');
    if($userId)
        $this->db->where('tbl_tournament.user_id', $userId);
    if($sports_category)
        $this->db->where_in('tbl_tournament.sports_category', $sports_category);

    if($state)
        $this->db->where_in('tbl_tournament.state', $state);
    if($city)
        $this->db->where_in('tbl_tournament.city', $city);
    if($status!='')
       $this->db->where_in('tbl_tournament.status', $status);

     return $this->db->where('tbl_tournament.status!=',2)->get('tbl_tournament')->result();
}

public function get_teamdata()
{
    $userId = $this->input->post('user_id');
    $game_category = json_decode($this->input->post('game_category'));
    $state = json_decode($this->input->post('state'));
    $city = json_decode($this->input->post('city'));
    $status = json_decode($this->input->post('status'));
    
    $this->db->select('tb_gamecategory.title as game_category ,tbl_users.name as team_name,tbl_users.image,tbl_users.id as team_id,tbl_users.username,tbl_users.email,tbl_users.mobile,tbl_users.status');
    $this->db->join('tb_gamecategory','tb_gamecategory.id=tbl_users.game_category','left');
    
     if($userId)
             $this->db->where('tbl_users.id',$userId);
      if($this->input->post('game_category'))
            $this->db->where_in('tbl_users.game_category',$this->input->post('game_category'));
     if($state)
             $this->db->where_in('tbl_users.state',$state);
    if($city)
            $this->db->where_in('tbl_users.city',$city);
     if($status!='')
            $this->db->where_in('tbl_users.status',$status);
   return $this->db->where(['tbl_users.status!='=>2,'type'=>1])->group_by('tbl_users.id')->get('tbl_users')->result();
}

public function get_allplayers()
{
     $userId = $this->input->post('user_id');
    $game_category = json_decode($this->input->post('game_category'));
    $state = json_decode($this->input->post('state'));
    $city = json_decode($this->input->post('city'));
    $status = json_decode($this->input->post('status'));
    
    $this->db->select('tbl_users.image,tbl_users.username,tb_gamecategory.title as game_category,tbl_users.amount,tbl_users.email,tbl_users.mobile,tbl_users.status,tbl_users.id');
    $this->db->join('tb_gamecategory','tb_gamecategory.id=tbl_users.game_category','left');
          if($game_category)
           $this->db->where_in('tbl_users.game_category',$game_category);
     if($state)
       $this->db->where_in('tbl_users.state',$state);
    if($city)
       $this->db->where_in('tbl_users.city',$city);
     if($status!='')
       $this->db->where_in('tbl_users.status',$status);

   return $this->db->where(['tbl_users.type'=>0,'tbl_users.status!='=>2])->group_by('tbl_users.id')->get('tbl_users')->result();
}


public function set_upload_files($upload_path ,$files,$type="")
{
    $image_base64 = base64_decode($files);
    
    if($type!="" && $type!=null){
        $file = $upload_path . uniqid() . '.'.$type;
    }else{
        $file = $upload_path . uniqid() . '.png';
    }
    file_put_contents($file, $image_base64); 
    $image = $file;
    return $image;
}
public function set_upload_multi_files($upload_path ,$files,$type="")
{
$files=json_decode($files);
     $upload_path = 'assets/gallery_image/';
    $collectArr=[];
    foreach($files as $each_image){
       
        $image_base64 = base64_decode($each_image);
      
        if($type!="" && $type!=null){
            $name=uniqid() . '.'.$type;
            $file = $upload_path . $name;
        }else{
             $name=uniqid() . '.png';
            $file = $upload_path . $name;
        }
        file_put_contents($file, $image_base64); 
        $collectArr[]=$image = $name;
    }
    
   
    return json_encode($collectArr);
}
public function get_tournementdetail($id)
{
    $this->db->select('tbl_sportcategory.title,tbl_tournament.user_id,tbl_tournament.id,tbl_tournament.tournament_title, tbl_tournament.fee as amount, tbl_tournament.description, tbl_tournament.status, tbl_tournament.cover_image as image');
    $this->db->join('tbl_sportcategory','tbl_sportcategory.id=tbl_tournament.sports_category','left');

   return $this->db->where('tbl_tournament.status',1)->where('tbl_tournament.user_id',$id)->get('tbl_tournament')->result_array();
}




public function get_userdata($id)
{
    $this->db->select('tbl_users.image,tbl_users.username,tb_gamecategory.title as game_category,tbl_users.email,tbl_users.mobile,tbl_users.id ');
    $this->db->join('tb_gamecategory',' tb_gamecategory.id=tbl_users.game_category','left');
    return $this->db->where(['tbl_users.status'=>1,'tbl_users.id'=>$id,'type'=>1])->get('tbl_users')->row_array();
}
public function login_get()
{
    $userdata = array();
//$query = $this->db->
    $this->db->select('tbl_users.id,tbl_users.name,tbl_users.username,tbl_users.mobile,tbl_users.email,tbl_users.game_category,tbl_users.experience,tbl_users.district,tbl_district.name as district_name,tbl_users.description,tbl_users.amount,tbl_users.image,tbl_users.status,tbl_users.city, tbl_city.name as city_name,tbl_users.state, tbl_state.name as state_name,
tbl_users.pincode,tbl_pincode.name as pincode_name,tbl_users.password,
    tb_gamecategory.title as game_category,tbl_users.is_block,tbl_users.game_category as game_category_id');
    $this->db->join('tb_gamecategory',' tb_gamecategory.id=tbl_users.game_category','left');
    $this->db->join('tbl_city','tbl_city.id=tbl_users.city','left');
    $this->db->join('tbl_state',' tbl_state.id=tbl_users.state','left');
         $this->db->join('tbl_district',' tbl_district.id=tbl_users.district','left');
     $this->db->join('tbl_pincode',' tbl_pincode.id=tbl_users.pincode','left');
   $query= $this->db->where('tbl_users.status in(0,1)')->where('tbl_users.mobile',$this->input->post('mobile'))->where('tbl_users.type',$this->input->post('type'))->or_where('tbl_users.email',$this->input->post('mobile'))->get('tbl_users');
    if ($query->num_rows() > 0) 
    {
        $row = $query->row_array();
        if($row['status'] == 1 )
        {
            if($row['password'] == md5($this->input->post('password')))
            {
                    $userdata = $row;
                    $userdata['login_status'] = 1;
            } 
           
            else
            {
                $userdata['login_status'] = 3;
            }
        } 
   

        else
        {
           $userdata['login_status'] = 2; 
        }
              
}
    else 
    {
        
        $userdata['login_status'] = 0;
    }
    
    
    
    return $userdata;
}

function send_otp($mobile){
    $otp_array=array();
   $user_data= $this->db->where('mobile',$mobile)->or_where('email',$mobile)->get('tbl_users');
   if($user_data->num_rows()>0)
   {
         
         if($user_data->row()->is_register==1)
         {
       $otp = rand(1000, 9999);
       $status=0;
       $check_otp=$this->db->query("select * from tblotp where mobile='".$mobile."' and type='f'");
       if($check_otp->num_rows()>0) {
           $q2=$this->db->query("update tblotp set otp='".$otp."' where mobile='".$mobile."' and type='f'");
       } 
       else 
       {
           $q2=$this->db->query("insert into tblotp (otp,type,mobile) values ('".$otp."','f','".$mobile."') ");
       }
       if($q2) 
       {
           $otp_array['status']=1;
           $otp_array['status_1']=$otp;
           // return $otp;
       }
           
          
       
       else 
       {
             $otp_array['status']=2;
          // return $status;
       }
       
         }
         
      else
       {
       $otp_array['status']=3;
       }
       
   }
   else
   {
       $otp_array['status']=4;
      // return 0;
   }
   return $otp_array;
}

public function verify_otp()
{
        $otp_verification = array();
        $mobile=$this->input->post('mobile');
       $otp=$this->input->post('otp');
       $user_data=$this->db->where(['mobile'=>$mobile,'type'=>'f'])->get('tblotp');
       if($user_data->num_rows()>0)
        {
             
        $user_data_row = $user_data->row();
    //  print_r($user_data_row);exit;
            if($user_data_row->otp==$otp)
            {
            $data=$this->db->where(['mobile'=>$mobile,'type'=>'f'])->get('tbl_users')->row_array();
            $otp_verification = $data;
            $otp_verification['status']=1;
            }
            else
            {
            $otp_verification['status']=0;
            }
        }
 else
 {
    $otp_verification['status']=2; 
 }
 return $otp_verification;
}




public function get_teamplayer($id)
{
   
   return $this->db->where(['status'=>1,'user_id'=>$id])->get('tbl_teamplayers')->result();
}


public function get_achievements($id)
{
    return $this->db->select('id,title as achievement_name')->where(['status'=>1,'user_id'=>$id])->get('tbl_achievements')->result_array();
}
public function get_gallery($id)
{
    return $this->db->select('id,image')->where(['status'=>1,'user_id'=>$id])->get('tbl_playergallery')->result_array();
}
public function get_teamplayers($id)
{
   
    $this->db->select('id,player_name,position');
   return $this->db->where(['status'=>1,'user_id'=>$id])->get('tbl_teamplayers')->result_array();
}
public function get_singletournementdetail($tournement_id)
{
    $this->db->select('tbl_sportcategory.title as sport_category,tbl_tournament.user_id,tbl_tournament.tournament_title, tbl_tournament.fee as amount, tbl_tournament.description, tbl_tournament.status, tbl_tournament.cover_image as image');
    $this->db->join('tbl_sportcategory','tbl_sportcategory.id=tbl_tournament.sports_category','left');
//$this->db->join('tbl_users','tbl_users.id=tbl_tournament.user_id','left');
   return $this->db->where('tbl_tournament.status!=',2)->where('tbl_tournament.id',$tournement_id)->get('tbl_tournament')->row_array();
}
public function get_singlusersdata($id,$type)
{
    $this->db->select('tbl_users.id,tbl_users.name,tbl_users.username,tbl_users.mobile,tbl_users.email,tbl_users.game_category,tbl_users.experience,tbl_users.district,tbl_district.name as district_name,tbl_users.description,tbl_users.amount,tbl_users.image,tbl_users.status,tbl_users.city,tbl_city.name as city_name,tbl_users.state,tbl_state.name as state_name,
tbl_users.pincode,tbl_pincode.name as pincode_name,
    tb_gamecategory.title as game_category');
    $this->db->join('tb_gamecategory',' tb_gamecategory.id=tbl_users.game_category','left');
    $this->db->join('tbl_city','tbl_city.id=tbl_users.city','left');
    $this->db->join('tbl_state',' tbl_state.id=tbl_users.state','left');
         $this->db->join('tbl_district',' tbl_district.id=tbl_users.district','left');
     $this->db->join('tbl_pincode',' tbl_pincode.id=tbl_users.pincode','left');
    return $this->db->where(['tbl_users.status!='=>2,'tbl_users.id'=>$id,'type'=>$type])->get('tbl_users')->row_array();
}
public function get_profiledetails($user_id)
{
    $this->db->select('tbl_users.id,tbl_users.name,tbl_users.username,tbl_users.mobile,tbl_users.email,tbl_users.game_category,tbl_users.experience,tbl_users.district,tbl_district.name as district_name,tbl_users.description,tbl_users.amount,tbl_users.image,tbl_users.status,tbl_users.city ,tbl_users.state,
    tbl_users.pincode,tbl_pincode.name as pincode_name,tbl_users.password,
    
    tbl_achievements.title as achievements_title,tbl_achievements.description as achievements_desc, tbl_playergallery.image as gallery_image');
    $this->db->join('tbl_achievements','tbl_achievements.user_id=tbl_users.id','left');
    $this->db->join('tbl_playergallery',' tbl_playergallery.user_id=tbl_users.id','left');
    $this->db->join('tbl_city','tbl_city.id=tbl_users.city','left');
    $this->db->join('tbl_state',' tbl_state.id=tbl_users.state','left');
     $this->db->join('tbl_district',' tbl_district.id=tbl_users.district','left');
     $this->db->join('tbl_pincode',' tbl_pincode.id=tbl_users.pincode','left');
   return $this->db->where('tbl_users.is_register',1)->where('tbl_users.id',$user_id)->get('tbl_users')->row();
}


}